Project Overview

This project showcases an interactive Power BI dashboard built to analyze and visualize data in a meaningful way. The dashboard helps uncover trends, patterns, and insights that support better decision-making.

It converts raw data into clear, visual, and actionable insights using charts, KPIs, and filters.

 Project Goals
 Raw data ko clean & transform karna
 Interactive dashboard design karna
 Trends aur patterns identify karna
 Business insights generate karna
 Tools & Technologies Used
Power BI Desktop
Power Query (Data Cleaning)
DAX (Data Analysis Expressions)
Excel / CSV Dataset
 Project Structure
PR-3-Power-BI/
│──  Dataset
│──  Dashboard.pbix
│──  Screenshots
│──  README.md
 Dashboard Highlights
 Sales / Performance Analysis
 KPI Cards (Revenue, Profit, etc.)
 Time-based Trends (Monthly/Yearly)
 Category-wise Analysis
 Interactive Filters & Slicers
 Key Insights
Top performing categories/products
Profit vs Loss comparison
Growth trends over time
Data-driven decision support

 Dashboard Preview



<img width="1850" height="725" alt="Screenshot 2026-04-14 002203" src="https://github.com/user-attachments/assets/cb1c1804-45f5-4ab7-82ed-f1adf19ec943" />



<img width="1744" height="732" alt="Screenshot 2026-04-14 001939" src="https://github.com/user-attachments/assets/f4b9430f-f59d-48c5-bfc7-8e186f51b33f" />


